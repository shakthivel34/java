package assesment;
import java.util.*;

public class sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a,b,c;
		System.out.println("Enter the first integer: ");
		a=s.nextInt();
		System.out.println("Enter the second integer: ");
		b=s.nextInt();
		System.out.println("Enter the third integer: ");
		c=s.nextInt();
		int result=a+b+c;
		System.out.println("The sum of three integers:  "+result);
		
		
		

	}

}
