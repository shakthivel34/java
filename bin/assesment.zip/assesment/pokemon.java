package assesment;
import java.util.*;
public class pokemon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
		int num1,num2;
		System.out.println("Enter the number of pokemons: ");
		num1=s.nextInt();
		System.out.println("Enter the number of pokemon balls: ");
		num2=s.nextInt();
		if (num1==num2)
		{
			System.out.println("1");
			
		}
		else 
		{
			System.out.println("0");
		}
		
		

	}

}
