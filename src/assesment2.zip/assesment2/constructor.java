package assesment2;

public class constructor {
	double width,height,depth,result;
	public constructor()
	{
		width=10;
		height=10;
		depth=10;
		result=width*height*depth;
		System.out.println("The volume without parameter : "+result);
	}
	public constructor (double w,double h,double d)
	{
		double result1=w*h*d;
		System.out.println("The volume with parameter : "+result1);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		constructor s=new constructor();
		constructor s1=new constructor(8,9,11);

	}

}
